package com.gestion.etudiants.services;
import com.gestion.etudiants.controller.dto.NiveauDTO;
import com.gestion.etudiants.entites.NiveauEntite;
import com.gestion.etudiants.repositories.NiveauRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class NiveauServiceImpl implements NiveauService {

    @Autowired
    private NiveauRepository niveauRepository;

    @Override
    public List<NiveauDTO> getAllNiveaux() {
        return niveauRepository.findAll().stream()
                .map(NiveauDTO::fromEntity)
                .collect(Collectors.toList());
    }

    @Override
    public NiveauDTO getNiveauById(int id) {
        return niveauRepository.findById(id)
                .map(NiveauDTO::fromEntity)
                .orElse(null);
    }

    @Override
    public NiveauDTO addNiveau(NiveauDTO niveauDTO) {
        NiveauEntite niveau = niveauDTO.toEntity();
        NiveauEntite savedNiveau = niveauRepository.save(niveau);
        return NiveauDTO.fromEntity(savedNiveau);
    }

    @Override
    public NiveauDTO updateNiveau(int id, NiveauDTO niveauDTO) {
        Optional<NiveauEntite> existingNiveau = niveauRepository.findById(id);

        if (existingNiveau.isPresent()) {
            NiveauEntite niveauToUpdate = existingNiveau.get();

            // Mettez à jour les propriétés de l'entité avec les valeurs du DTO
            niveauToUpdate.setLibelle(niveauDTO.getLibelle());
            niveauToUpdate.setFiliere(niveauDTO.getFiliere().toEntity());

            NiveauEntite updatedNiveau = niveauRepository.save(niveauToUpdate);
            return NiveauDTO.fromEntity(updatedNiveau);
        }
        return null;
    }

    @Override
    public void deleteNiveau(int id) {

    }
}
