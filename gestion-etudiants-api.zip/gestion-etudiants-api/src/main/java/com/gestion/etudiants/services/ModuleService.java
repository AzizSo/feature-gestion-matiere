package com.gestion.etudiants.services;

import com.gestion.etudiants.controller.dto.ModuleDTO;

import java.util.List;

public interface ModuleService {
    List<ModuleDTO> getAllModules();
    ModuleDTO getModuleById(int id);
    ModuleDTO addModule(ModuleDTO moduleDTO);
    ModuleDTO updateModule(int id, ModuleDTO moduleDTO);
    void deleteModule(int id);
}

