package com.gestion.etudiants.controller.dto;

import com.gestion.etudiants.entites.NiveauEntite;

public class NiveauDTO {
    private int idNiveau;
    private String libelle;
    private FiliereDTO filiere;

    // Constructeurs, getters et setters

    public NiveauDTO() {
        // Constructeur par défaut
    }

    public NiveauDTO(int idNiveau, String libelle, FiliereDTO filiere) {
        this.idNiveau = idNiveau;
        this.libelle = libelle;
        this.filiere = filiere;
    }

    // Getters

    public int getIdNiveau() {
        return idNiveau;
    }

    public String getLibelle() {
        return libelle;
    }

    public FiliereDTO getFiliere() {
        return filiere;
    }

    // Setters

    public void setIdNiveau(int idNiveau) {
        this.idNiveau = idNiveau;
    }

    public void setLibelle(String libelle) {
        this.libelle = libelle;
    }

    public void setFiliere(FiliereDTO filiere) {
        this.filiere = filiere;
    }
    public static NiveauDTO fromEntity(NiveauEntite niveau) {
        NiveauDTO niveauDTO = new NiveauDTO();
        niveauDTO.setIdNiveau(niveau.getIdNiveau());
        niveauDTO.setLibelle(niveau.getLibelle());
        niveauDTO.setFiliere(FiliereDTO.fromEntity(niveau.getFiliere()));
        return niveauDTO;
    }

    public NiveauEntite toEntity() {
        NiveauEntite niveau = new NiveauEntite();
        niveau.setIdNiveau(this.idNiveau);
        niveau.setLibelle(this.libelle);
        niveau.setFiliere(this.filiere.toEntity());
        return niveau;
    }
}

