package com.gestion.etudiants.controller;

import com.gestion.etudiants.controller.dto.InscriptionDTO;
import com.gestion.etudiants.services.InscriptionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/inscriptions")
public class InscriptionController {

    @Autowired
    private InscriptionService inscriptionService;

    @GetMapping
    public ResponseEntity<List<InscriptionDTO>> obtenirListeInscriptions() {
        List<InscriptionDTO> inscriptions = inscriptionService.getAllInscriptions();
        return new ResponseEntity<>(inscriptions, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<InscriptionDTO> obtenirInscriptionParId(@PathVariable int id) {
        InscriptionDTO inscription = inscriptionService.getInscriptionById(id);
        return new ResponseEntity<>(inscription, HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<InscriptionDTO> creerInscription(@RequestBody InscriptionDTO inscriptionDTO) {
        InscriptionDTO inscriptionCree = inscriptionService.addInscription(inscriptionDTO);
        return new ResponseEntity<>(inscriptionCree, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<InscriptionDTO> mettreAJourInscription(@PathVariable int id, @RequestBody InscriptionDTO inscriptionDTO) {
        InscriptionDTO inscriptionMiseAJour = inscriptionService.updateInscription(id, inscriptionDTO);
        return new ResponseEntity<>(inscriptionMiseAJour, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> supprimerInscription(@PathVariable int id) {
        inscriptionService.deleteInscription(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}

