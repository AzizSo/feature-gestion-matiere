package com.gestion.etudiants.services;

import com.gestion.etudiants.controller.dto.NiveauDTO;

import java.util.List;

public interface NiveauService {
    List<NiveauDTO> getAllNiveaux();

    NiveauDTO getNiveauById(int id);

    NiveauDTO addNiveau(NiveauDTO niveauDTO);

    NiveauDTO updateNiveau(int id, NiveauDTO niveauDTO);

    void deleteNiveau(int id);
}

