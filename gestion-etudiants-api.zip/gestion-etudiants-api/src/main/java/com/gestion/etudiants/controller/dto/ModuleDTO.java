package com.gestion.etudiants.controller.dto;

import com.gestion.etudiants.entites.ModuleEntite;

public class ModuleDTO {
    private int idModule;
    private String nom;
    private FiliereDTO filiere;
    // D'autres attributs si nécessaire

    // Constructeurs
    public ModuleDTO() {
        // Constructeur par défaut
    }

    public ModuleDTO(int idModule, String nom, FiliereDTO filiere) {
        this.idModule = idModule;
        this.nom = nom;
        this.filiere = filiere;
    }

    // Getters
    public int getIdModule() {
        return idModule;
    }

    public String getNom() {
        return nom;
    }

    public FiliereDTO getFiliere() {
        return filiere;
    }

    // Setters
    public void setIdModule(int idModule) {
        this.idModule = idModule;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public void setFiliere(FiliereDTO filiere) {
        this.filiere = filiere;
    }

    // Méthode de conversion de l'entité vers le DTO
    public static ModuleDTO fromEntity(ModuleEntite module) {
        ModuleDTO moduleDTO = new ModuleDTO();
        moduleDTO.setIdModule(module.getIdModule());
        moduleDTO.setNom(module.getNom());
        moduleDTO.setFiliere(FiliereDTO.fromEntity(module.getFiliere()));
        // Assurez-vous de gérer la conversion des matières si nécessaire
        return moduleDTO;
    }

    // Méthode de conversion du DTO vers l'entité
    public ModuleEntite toEntity() {
        ModuleEntite module = new ModuleEntite();
        module.setIdModule(this.idModule);
        module.setNom(this.nom);
        module.setFiliere(this.filiere.toEntity());
        // Assurez-vous de gérer la conversion des matières si nécessaire
        return module;
    }
}

