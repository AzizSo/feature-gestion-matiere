package com.gestion.etudiants;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestionEtudiantsApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestionEtudiantsApiApplication.class, args);
	}

}
