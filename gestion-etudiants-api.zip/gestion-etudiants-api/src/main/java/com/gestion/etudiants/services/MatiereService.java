package com.gestion.etudiants.services;

import com.gestion.etudiants.controller.dto.MatiereDTO;

import java.util.List;

public interface MatiereService {
    List<MatiereDTO> getAllMatieres();
    MatiereDTO getMatiereById(int id);
    MatiereDTO addMatiere(MatiereDTO matiereDTO);
    MatiereDTO updateMatiere(int id, MatiereDTO matiereDTO);
    void deleteMatiere(int id);
}
