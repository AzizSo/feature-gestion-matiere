package com.gestion.etudiants.services;

import com.gestion.etudiants.controller.dto.InscriptionDTO;

import java.util.List;

public interface InscriptionService {
    List<InscriptionDTO> getAllInscriptions();

    InscriptionDTO getInscriptionById(int id);

    InscriptionDTO addInscription(InscriptionDTO inscriptionDTO);

    InscriptionDTO updateInscription(int id, InscriptionDTO inscriptionDTO);

    void deleteInscription(int id);
}
