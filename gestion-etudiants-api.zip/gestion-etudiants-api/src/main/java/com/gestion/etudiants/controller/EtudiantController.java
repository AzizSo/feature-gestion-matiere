package com.gestion.etudiants.controller;
import com.gestion.etudiants.controller.dto.EtudiantDTO;
import com.gestion.etudiants.services.EtudiantService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@RestController
@RequestMapping("/api/etudiants")
public class EtudiantController {

        @Autowired
        private EtudiantService etudiantService;

        @GetMapping
        public ResponseEntity<List<EtudiantDTO>> obtenirListeEtudiants() {
            List<EtudiantDTO> etudiants = etudiantService.getAllEtudiants();
            return new ResponseEntity<>(etudiants, HttpStatus.OK);
        }

        @GetMapping("/{id}")
        public ResponseEntity<EtudiantDTO> obtenirEtudiantParId(@PathVariable int id) {
            EtudiantDTO etudiant = etudiantService.getEtudiantById(id);
            return new ResponseEntity<>(etudiant, HttpStatus.OK);
        }

        @PostMapping
        public ResponseEntity<EtudiantDTO> creerEtudiant(@RequestBody EtudiantDTO etudiantDTO) {
            EtudiantDTO etudiantCree = etudiantService.addEtudiant(etudiantDTO);
            return new ResponseEntity<>(etudiantCree, HttpStatus.CREATED);
        }

        @PutMapping("/{id}")
        public ResponseEntity<EtudiantDTO> mettreAJourEtudiant(@PathVariable int id, @RequestBody EtudiantDTO etudiantDTO) {
            EtudiantDTO etudiantMiseAJour = etudiantService.updateEtudiant(id, etudiantDTO);
            return new ResponseEntity<>(etudiantMiseAJour, HttpStatus.OK);
        }

        @DeleteMapping("/{id}")
        public ResponseEntity<Void> supprimerEtudiant(@PathVariable int id) {
            etudiantService.deleteEtudiant(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }
}


