package com.gestion.etudiants.services;

import com.gestion.etudiants.controller.dto.InscriptionDTO;
import com.gestion.etudiants.entites.InscriptionEntite;
import com.gestion.etudiants.repositories.InscriptionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class InscriptionServiceImpl implements InscriptionService {

    @Autowired
    private InscriptionRepository inscriptionRepository;

    @Override
    public List<InscriptionDTO> getAllInscriptions() {
        return inscriptionRepository.findAll().stream()
                .map(InscriptionDTO::fromEntity)
                .collect(Collectors.toList());
    }

    @Override
    public InscriptionDTO getInscriptionById(int id) {
        return inscriptionRepository.findById(id)
                .map(InscriptionDTO::fromEntity)
                .orElse(null);
    }

    @Override
    public InscriptionDTO addInscription(InscriptionDTO inscriptionDTO) {
        InscriptionEntite inscription = inscriptionDTO.toEntity();
        InscriptionEntite savedInscription = inscriptionRepository.save(inscription);
        return InscriptionDTO.fromEntity(savedInscription);
    }

    @Override
    public InscriptionDTO updateInscription(int id, InscriptionDTO inscriptionDTO) {
        Optional<InscriptionEntite> existingInscription = inscriptionRepository.findById(id);

        if (existingInscription.isPresent()) {
            InscriptionEntite inscriptionToUpdate = existingInscription.get();

            // Mettez à jour les propriétés de l'entité avec les valeurs du DTO
            inscriptionToUpdate.setDateInscription(inscriptionDTO.getDateInscription());
            inscriptionToUpdate.setEtudiant(inscriptionDTO.getEtudiant().toEntity());
            inscriptionToUpdate.setNiveau(inscriptionDTO.getNiveau().toEntity());

            InscriptionEntite updatedInscription = inscriptionRepository.save(inscriptionToUpdate);
            return InscriptionDTO.fromEntity(updatedInscription);
        }
        return null;
    }

    @Override
    public void deleteInscription(int id) {
        inscriptionRepository.deleteById(id);
    }
}

