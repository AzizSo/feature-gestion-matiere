package com.gestion.etudiants.controller;

import com.gestion.etudiants.controller.dto.ModuleDTO;
import com.gestion.etudiants.services.ModuleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("api/modules/")
public class ModuleController {

    @Autowired
    private ModuleService moduleService;

    @GetMapping
    public ResponseEntity<List<ModuleDTO>> getAllModules() {
        List<ModuleDTO> modules = moduleService.getAllModules();
        return ResponseEntity.ok(modules);
    }

    @GetMapping("{id}")
    public ResponseEntity<ModuleDTO> getModuleById(@PathVariable int id) {
        ModuleDTO module = moduleService.getModuleById(id);
        return module != null ? ResponseEntity.ok(module) : ResponseEntity.notFound().build();
    }

    @PostMapping
    public ResponseEntity<ModuleDTO> addModule(@RequestBody ModuleDTO moduleDTO) {
        ModuleDTO addedModule = moduleService.addModule(moduleDTO);
        return ResponseEntity.ok(addedModule);
    }

    @PutMapping("{id}")
    public ResponseEntity<ModuleDTO> updateModule(@PathVariable int id, @RequestBody ModuleDTO moduleDTO) {
        ModuleDTO updatedModule = moduleService.updateModule(id, moduleDTO);
        return updatedModule != null ? ResponseEntity.ok(updatedModule) : ResponseEntity.notFound().build();
    }

    @DeleteMapping("{id}")
    public ResponseEntity<Void> deleteModule(@PathVariable int id) {
        moduleService.deleteModule(id);
        return ResponseEntity.noContent().build();
    }
}
