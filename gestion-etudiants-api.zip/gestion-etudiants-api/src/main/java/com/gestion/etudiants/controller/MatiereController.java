package com.gestion.etudiants.controller;

import com.gestion.etudiants.controller.dto.MatiereDTO;
import com.gestion.etudiants.services.MatiereService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("api/matieres/")
public class MatiereController {

    @Autowired
    private MatiereService matiereService;

    @GetMapping
    public ResponseEntity<List<MatiereDTO>> getAllMatieres() {
        List<MatiereDTO> matieres = matiereService.getAllMatieres();
        return ResponseEntity.ok(matieres);
    }

    @GetMapping("{id}")
    public ResponseEntity<MatiereDTO> getMatiereById(@PathVariable int id) {
        MatiereDTO matiere = matiereService.getMatiereById(id);
        return matiere != null ? ResponseEntity.ok(matiere) : ResponseEntity.notFound().build();
    }

    @PostMapping
    public ResponseEntity<MatiereDTO> addMatiere(@RequestBody MatiereDTO matiereDTO) {
        MatiereDTO addedMatiere = matiereService.addMatiere(matiereDTO);
        return ResponseEntity.ok(addedMatiere);
    }

    @PutMapping("{id}")
    public ResponseEntity<MatiereDTO> updateMatiere(@PathVariable int id, @RequestBody MatiereDTO matiereDTO) {
        MatiereDTO updatedMatiere = matiereService.updateMatiere(id, matiereDTO);
        return updatedMatiere != null ? ResponseEntity.ok(updatedMatiere) : ResponseEntity.notFound().build();
    }

    @DeleteMapping("{id}")
    public ResponseEntity<Void> deleteMatiere(@PathVariable int id) {
        matiereService.deleteMatiere(id);
        return ResponseEntity.noContent().build();
    }
}
