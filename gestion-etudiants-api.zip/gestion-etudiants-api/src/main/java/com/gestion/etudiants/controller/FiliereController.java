package com.gestion.etudiants.controller;

import com.gestion.etudiants.controller.dto.FiliereDTO;
import com.gestion.etudiants.services.FiliereService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/filieres")
public class FiliereController {

    @Autowired
    private FiliereService filiereService;

    @GetMapping
    public ResponseEntity<List<FiliereDTO>> obtenirListeFilieres() {
        List<FiliereDTO> filieres = filiereService.getAllFilieres();
        return new ResponseEntity<>(filieres, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<FiliereDTO> obtenirFiliereParId(@PathVariable Long id) {
        FiliereDTO filiere = filiereService.getFiliereById(id);
        return new ResponseEntity<>(filiere, HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<FiliereDTO> creerFiliere(@RequestBody FiliereDTO filiereDTO) {
        FiliereDTO filiereCree = filiereService.addFiliere(filiereDTO);
        return new ResponseEntity<>(filiereCree, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<FiliereDTO> mettreAJourFiliere(@PathVariable Long id, @RequestBody FiliereDTO filiereDTO) {
        FiliereDTO filiereMiseAJour = filiereService.updateFiliere(id, filiereDTO);
        return new ResponseEntity<>(filiereMiseAJour, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> supprimerFiliere(@PathVariable Long id) {
        filiereService.deleteFiliere(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
