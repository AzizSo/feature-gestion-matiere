package com.gestion.etudiants.services;

import java.util.List;

import com.gestion.etudiants.controller.dto.FiliereDTO;

public interface FiliereService {
	List<FiliereDTO> getAllFilieres();

	FiliereDTO getFiliereById(Long id);

	FiliereDTO addFiliere(FiliereDTO filiereDTO);

	FiliereDTO updateFiliere(Long id, FiliereDTO filiereDTO);

	void deleteFiliere(Long id);

}
