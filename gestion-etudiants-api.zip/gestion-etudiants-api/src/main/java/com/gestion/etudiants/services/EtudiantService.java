package com.gestion.etudiants.services;
import com.gestion.etudiants.controller.dto.EtudiantDTO;

import java.util.List;
    public interface EtudiantService {
        List<EtudiantDTO> getAllEtudiants();

        EtudiantDTO getEtudiantById(int id);

        EtudiantDTO addEtudiant(EtudiantDTO etudiantDTO);

        EtudiantDTO updateEtudiant(int id, EtudiantDTO etudiantDTO);

        void deleteEtudiant(int id);

    }


