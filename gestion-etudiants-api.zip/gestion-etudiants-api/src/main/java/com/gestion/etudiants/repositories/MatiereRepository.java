package com.gestion.etudiants.repositories;

import com.gestion.etudiants.entites.MatiereEntite;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MatiereRepository extends JpaRepository<MatiereEntite, Integer> {
    // Ajoutez des méthodes personnalisées si nécessaire
}
