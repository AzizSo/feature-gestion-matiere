package com.gestion.etudiants.services;
import com.gestion.etudiants.controller.dto.EtudiantDTO;
import com.gestion.etudiants.entites.EtudiantEntite;
import com.gestion.etudiants.repositories.EtudiantRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
    @Service
    public class EtudiantServiceImpl implements EtudiantService {

        @Autowired
        private EtudiantRepository etudiantRepository;

        @Override
        public List<EtudiantDTO> getAllEtudiants() {
            return etudiantRepository.findAll().stream()
                    .map(EtudiantDTO::fromEntity)
                    .collect(Collectors.toList());
        }

        @Override
        public EtudiantDTO getEtudiantById(int id) {
            return etudiantRepository.findById(id)
                    .map(EtudiantDTO::fromEntity)
                    .orElse(null);
        }

        @Override
        public EtudiantDTO addEtudiant(EtudiantDTO etudiantDTO) {
            EtudiantEntite etudiant = etudiantDTO.toEntity();
            EtudiantEntite savedEtudiant = etudiantRepository.save(etudiant);
            return EtudiantDTO.fromEntity(savedEtudiant);
        }


        @Override
        public EtudiantDTO updateEtudiant(int id, EtudiantDTO etudiantDTO) {
            Optional<EtudiantEntite> existingEtudiant = etudiantRepository.findById(id);

            if (existingEtudiant.isPresent()) {
                EtudiantEntite etudiantToUpdate = existingEtudiant.get();

                // Mettez à jour les propriétés de l'entité avec les valeurs du DTO
                etudiantToUpdate.setMatricule(etudiantDTO.getMatricule());
                etudiantToUpdate.setNom(etudiantDTO.getNom());
                etudiantToUpdate.setPrenom(etudiantDTO.getPrenom());
                etudiantToUpdate.setAdresse(etudiantDTO.getAdresse());
                etudiantToUpdate.setTelephone(etudiantDTO.getTelephone());
                etudiantToUpdate.setEmail(etudiantDTO.getEmail());
                etudiantToUpdate.setSexe(etudiantDTO.getSexe());
                etudiantToUpdate.setDateNaissance(etudiantDTO.getDateNaissance());

                EtudiantEntite updatedEtudiant = etudiantRepository.save(etudiantToUpdate);
                return EtudiantDTO.fromEntity(updatedEtudiant);
            }
            return null;
        }


        @Override
        public void deleteEtudiant(int id) {
            etudiantRepository.deleteById(id);
        }
    }


