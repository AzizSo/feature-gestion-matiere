package com.gestion.etudiants.controller.dto;
import com.gestion.etudiants.entites.EtudiantEntite;

import java.util.Date;
public class EtudiantDTO {

        private int idEtudiant;
        private String matricule;
        private String nom;
        private String prenom;
        private String adresse;
        private String telephone;
        private String email;
        private String sexe;
        private Date dateNaissance;

        // Constructeurs, getters et setters
    // Constructeurs

    public EtudiantDTO() {
        // Constructeur par défaut
    }

    // Constructeur avec tous les champs
    public EtudiantDTO(int idEtudiant, String matricule, String nom, String prenom, String adresse,
                       String telephone, String email, String sexe, Date dateNaissance) {
        this.idEtudiant = idEtudiant;
        this.matricule = matricule;
        this.nom = nom;
        this.prenom = prenom;
        this.adresse = adresse;
        this.telephone = telephone;
        this.email = email;
        this.sexe = sexe;
        this.dateNaissance = dateNaissance;
    }

    // Getters

    public int getIdEtudiant() {
        return idEtudiant;
    }

    public String getMatricule() {
        return matricule;
    }

    public String getNom() {
        return nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public String getAdresse() {
        return adresse;
    }

    public String getTelephone() {
        return telephone;
    }

    public String getEmail() {
        return email;
    }

    public String getSexe() {
        return sexe;
    }

    public Date getDateNaissance() {
        return dateNaissance;
    }

    // Setters

    public void setIdEtudiant(int idEtudiant) {
        this.idEtudiant = idEtudiant;
    }

    public void setMatricule(String matricule) {
        this.matricule = matricule;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public void setAdresse(String adresse) {
        this.adresse = adresse;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setSexe(String sexe) {
        this.sexe = sexe;
    }

    public void setDateNaissance(Date dateNaissance) {
        this.dateNaissance = dateNaissance;
    }


        public static EtudiantDTO fromEntity(EtudiantEntite etudiant) {
            EtudiantDTO etudiantDTO = new EtudiantDTO();
            etudiantDTO.setIdEtudiant(etudiant.getIdEtudiant());
            etudiantDTO.setMatricule(etudiant.getMatricule());
            etudiantDTO.setNom(etudiant.getNom());
            etudiantDTO.setPrenom(etudiant.getPrenom());
            etudiantDTO.setAdresse(etudiant.getAdresse());
            etudiantDTO.setTelephone(etudiant.getTelephone());
            etudiantDTO.setEmail(etudiant.getEmail());
            etudiantDTO.setSexe(etudiant.getSexe());
            etudiantDTO.setDateNaissance(etudiant.getDateNaissance());
            return etudiantDTO;
        }

    public EtudiantEntite toEntity() {
            EtudiantEntite etudiant = new EtudiantEntite();
            etudiant.setIdEtudiant(this.idEtudiant);
            etudiant.setMatricule(this.matricule);
            etudiant.setNom(this.nom);
            etudiant.setPrenom(this.prenom);
            etudiant.setAdresse(this.adresse);
            etudiant.setTelephone(this.telephone);
            etudiant.setEmail(this.email);
            etudiant.setSexe(this.sexe);
            etudiant.setDateNaissance(this.dateNaissance);
            return etudiant;
        }
}

