package com.gestion.etudiants;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionEtudiantsApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
