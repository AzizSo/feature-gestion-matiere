package com.gestion.etudiants.controller;

import com.gestion.etudiants.controller.dto.NiveauDTO;
import com.gestion.etudiants.services.NiveauService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/niveaux")
public class NiveauController {

    @Autowired
    private NiveauService niveauService;

    @GetMapping
    public ResponseEntity<List<NiveauDTO>> obtenirListeNiveaux() {
        List<NiveauDTO> niveaux = niveauService.getAllNiveaux();
        return new ResponseEntity<>(niveaux, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<NiveauDTO> obtenirNiveauParId(@PathVariable int id) {
        NiveauDTO niveau = niveauService.getNiveauById(id);
        return new ResponseEntity<>(niveau, HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<NiveauDTO> creerNiveau(@RequestBody NiveauDTO niveauDTO) {
        NiveauDTO niveauCree = niveauService.addNiveau(niveauDTO);
        return new ResponseEntity<>(niveauCree, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<NiveauDTO> mettreAJourNiveau(@PathVariable int id, @RequestBody NiveauDTO niveauDTO) {
        NiveauDTO niveauMiseAJour = niveauService.updateNiveau(id, niveauDTO);
        return new ResponseEntity<>(niveauMiseAJour, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> supprimerNiveau(@PathVariable int id) {
        niveauService.deleteNiveau(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
