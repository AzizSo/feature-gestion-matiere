package com.gestion.etudiants.repositories;
import com.gestion.etudiants.entites.EtudiantEntite;
import com.gestion.etudiants.entites.FiliereEntite;
import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.data.jpa.repository.JpaRepository;

public interface EtudiantRepository extends JpaRepository<EtudiantEntite, Integer> {
    // Vous pouvez ajouter des méthodes personnalisées ici si nécessaire
}
