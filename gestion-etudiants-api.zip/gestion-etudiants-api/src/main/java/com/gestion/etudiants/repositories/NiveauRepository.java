package com.gestion.etudiants.repositories;

import com.gestion.etudiants.entites.NiveauEntite;
import org.springframework.data.jpa.repository.JpaRepository;

public interface NiveauRepository extends JpaRepository<NiveauEntite, Integer> {
    // Vous pouvez ajouter des méthodes personnalisées ici si nécessaire
}

