INSERT INTO filiere (nom,duree,description)VALUES ('Informatique de Gestion',3,'Filiere inf');
INSERT INTO filiere (nom,duree,description)VALUES ('Mecanique',3,'Filiere mecanique');
