package com.gestion.etudiants.services;

import com.gestion.etudiants.controller.dto.ModuleDTO;
import com.gestion.etudiants.entites.ModuleEntite;
import com.gestion.etudiants.repositories.ModuleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ModuleServiceImpl implements ModuleService {

    @Autowired
    private ModuleRepository moduleRepository;

    @Override
    public List<ModuleDTO> getAllModules() {
        return moduleRepository.findAll().stream()
                .map(ModuleDTO::fromEntity)
                .collect(Collectors.toList());
    }

    @Override
    public ModuleDTO getModuleById(int id) {
        return moduleRepository.findById(id)
                .map(ModuleDTO::fromEntity)
                .orElse(null);
    }

    @Override
    public ModuleDTO addModule(ModuleDTO moduleDTO) {
        ModuleEntite module = moduleDTO.toEntity();
        ModuleEntite savedModule = moduleRepository.save(module);
        return ModuleDTO.fromEntity(savedModule);
    }

    @Override
    public ModuleDTO updateModule(int id, ModuleDTO moduleDTO) {
        Optional<ModuleEntite> existingModule = moduleRepository.findById(id);

        if (existingModule.isPresent()) {
            ModuleEntite moduleToUpdate = existingModule.get();
            // Mettez à jour les propriétés de l'entité avec les valeurs du DTO
            moduleToUpdate.setNom(moduleDTO.getNom());
            moduleToUpdate.setFiliere(moduleDTO.getFiliere().toEntity());

            ModuleEntite updatedModule = moduleRepository.save(moduleToUpdate);
            return ModuleDTO.fromEntity(updatedModule);
        }
        return null;
    }

    @Override
    public void deleteModule(int id) {
        moduleRepository.deleteById(id);
    }
}
