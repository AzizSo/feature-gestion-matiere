package com.gestion.etudiants.services;

import com.gestion.etudiants.controller.dto.MatiereDTO;
import com.gestion.etudiants.entites.MatiereEntite;
import com.gestion.etudiants.repositories.MatiereRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class MatiereServiceImpl implements MatiereService {

    @Autowired
    private MatiereRepository matiereRepository;

    @Override
    public List<MatiereDTO> getAllMatieres() {
        return matiereRepository.findAll().stream()
                .map(MatiereDTO::fromEntity)
                .collect(Collectors.toList());
    }

    @Override
    public MatiereDTO getMatiereById(int id) {
        return matiereRepository.findById(id)
                .map(MatiereDTO::fromEntity)
                .orElse(null);
    }

    @Override
    public MatiereDTO addMatiere(MatiereDTO matiereDTO) {
        MatiereEntite matiere = matiereDTO.toEntity();
        MatiereEntite savedMatiere = matiereRepository.save(matiere);
        return MatiereDTO.fromEntity(savedMatiere);
    }

    @Override
    public MatiereDTO updateMatiere(int id, MatiereDTO matiereDTO) {
        Optional<MatiereEntite> existingMatiere = matiereRepository.findById(id);

        if (existingMatiere.isPresent()) {
            MatiereEntite matiereToUpdate = existingMatiere.get();
            // Mettez à jour les propriétés de l'entité avec les valeurs du DTO
            matiereToUpdate.setNom(matiereDTO.getNom());
            matiereToUpdate.setVolumeHoraire(matiereDTO.getVolumeHoraire());
            matiereToUpdate.setModule(matiereDTO.getModule().toEntity());

            MatiereEntite updatedMatiere = matiereRepository.save(matiereToUpdate);
            return MatiereDTO.fromEntity(updatedMatiere);
        }
        return null;
    }

    @Override
    public void deleteMatiere(int id) {
        matiereRepository.deleteById(id);
    }
}
