package com.gestion.etudiants.controller.dto;

import com.gestion.etudiants.entites.InscriptionEntite;

import java.util.Date;

public class InscriptionDTO {
    private int idInscription;
    private Date dateInscription;
    private EtudiantDTO etudiant;
    private NiveauDTO niveau;

    // Constructeurs, getters et setters
    // Constructeurs

    public InscriptionDTO() {
        // Constructeur par défaut
    }

    public InscriptionDTO(int idInscription, Date dateInscription, EtudiantDTO etudiant, NiveauDTO niveau) {
        this.idInscription = idInscription;
        this.dateInscription = dateInscription;
        this.etudiant = etudiant;
        this.niveau = niveau;
    }

    // Getters

    public int getIdInscription() {
        return idInscription;
    }

    public Date getDateInscription() {
        return dateInscription;
    }

    public EtudiantDTO getEtudiant() {
        return etudiant;
    }

    public NiveauDTO getNiveau() {
        return niveau;
    }

    // Setters

    public void setIdInscription(int idInscription) {
        this.idInscription = idInscription;
    }

    public void setDateInscription(Date dateInscription) {
        this.dateInscription = dateInscription;
    }

    public void setEtudiant(EtudiantDTO etudiant) {
        this.etudiant = etudiant;
    }

    public void setNiveau(NiveauDTO niveau) {
        this.niveau = niveau;
    }


    public static InscriptionDTO fromEntity(InscriptionEntite inscription) {
        InscriptionDTO inscriptionDTO = new InscriptionDTO();
        inscriptionDTO.setIdInscription(inscription.getIdInscription());
        inscriptionDTO.setDateInscription(inscription.getDateInscription());
        inscriptionDTO.setEtudiant(EtudiantDTO.fromEntity(inscription.getEtudiant()));
        inscriptionDTO.setNiveau(NiveauDTO.fromEntity(inscription.getNiveau()));
        return inscriptionDTO;
    }

    public InscriptionEntite toEntity() {
        InscriptionEntite inscription = new InscriptionEntite();
        inscription.setIdInscription(this.idInscription);
        inscription.setDateInscription(this.dateInscription);
        inscription.setEtudiant(this.etudiant.toEntity());
        inscription.setNiveau(this.niveau.toEntity());
        return inscription;
    }
}
