package com.gestion.etudiants.controller.dto;

import com.gestion.etudiants.entites.FiliereEntite;

public class FiliereDTO {
	private int identifiantFiliere;
	private String nomFiliere;
	private String descriptionFiliere;

	public int getIdFiliere() {
		return identifiantFiliere;
	}

	public void setIdFiliere(int idFiliere) {
		this.identifiantFiliere = idFiliere;
	}

	public String getNom() {
		return nomFiliere;
	}

	public void setNom(String nom) {
		this.nomFiliere = nom;
	}

	/*public int getDuree() {
		return duree;
	}*/

	/*public void setDuree(int duree) {
		this.duree = duree;
	}*/

	public String getDescription() {
		return descriptionFiliere;
	}

	public void setDescription(String description) {
		this.descriptionFiliere = description;
	}

	public int getIdentifiantFiliere() {
		return identifiantFiliere;
	}
	public void setIdentifiantFiliere(int identifiantFiliere) {
		this.identifiantFiliere = identifiantFiliere;
	}
	public String getNomFiliere() {
		return nomFiliere;
	}
	public void setNomFiliere(String nomFiliere) {
		this.nomFiliere = nomFiliere;
	}
	public String getDescriptionFiliere() {
		return descriptionFiliere;
	}
	public void setDescriptionFiliere(String descriptionFiliere) {
		this.descriptionFiliere = descriptionFiliere;
	}
	
	public FiliereDTO() {
		super();
		// TODO Auto-generated constructor stub
	}


	public static FiliereDTO fromEntity(FiliereEntite filiere) {
		FiliereDTO filiereDTO = new FiliereDTO();
		filiereDTO.setIdFiliere(filiere.getIdFiliere());
		filiereDTO.setNom(filiere.getNom());
		//filiereDTO.setDuree(filiere.getDuree());
		filiereDTO.setDescription(filiere.getDescription());
		// Assignez d'autres attributs si nécessaire
		return filiereDTO;
	}

	public FiliereEntite toEntity() {
		FiliereEntite filiere = new FiliereEntite();
		filiere.setIdFiliere(this.identifiantFiliere);
		filiere.setNom(this.nomFiliere);
		//filiere.setDuree(this.duree);
		filiere.setDescription(this.descriptionFiliere);
		// Assurez-vous de gérer la conversion des modules, niveaux, etc., si nécessaire
		return filiere;
	}




}
