package com.gestion.etudiants.repositories;

import com.gestion.etudiants.entites.InscriptionEntite;
import org.springframework.data.jpa.repository.JpaRepository;

public interface InscriptionRepository extends JpaRepository<InscriptionEntite, Integer> {
    // Vous pouvez ajouter des méthodes personnalisées ici si nécessaire
}
