package com.gestion.etudiants.controller.dto;

import com.gestion.etudiants.entites.MatiereEntite;

public class MatiereDTO {
    private int idMatiere;
    private String nom;
    private int volumeHoraire;
    private ModuleDTO module;
    // D'autres attributs si nécessaire

    // Constructeurs
    public MatiereDTO() {
        // Constructeur par défaut
    }

    public MatiereDTO(int idMatiere, String nom, int volumeHoraire, ModuleDTO module) {
        this.idMatiere = idMatiere;
        this.nom = nom;
        this.volumeHoraire = volumeHoraire;
        this.module = module;
    }

    // Getters
    public int getIdMatiere() {
        return idMatiere;
    }

    public String getNom() {
        return nom;
    }

    public int getVolumeHoraire() {
        return volumeHoraire;
    }

    public ModuleDTO getModule() {
        return module;
    }

    // Setters
    public void setIdMatiere(int idMatiere) {
        this.idMatiere = idMatiere;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public void setVolumeHoraire(int volumeHoraire) {
        this.volumeHoraire = volumeHoraire;
    }

    public void setModule(ModuleDTO module) {
        this.module = module;
    }

    // Méthode de conversion de l'entité vers le DTO
    public static MatiereDTO fromEntity(MatiereEntite matiere) {
        MatiereDTO matiereDTO = new MatiereDTO();
        matiereDTO.setIdMatiere(matiere.getIdMatiere());
        matiereDTO.setNom(matiere.getNom());
        matiereDTO.setVolumeHoraire(matiere.getVolumeHoraire());
        matiereDTO.setModule(ModuleDTO.fromEntity(matiere.getModule()));
        // Assurez-vous de gérer la conversion des autres attributs si nécessaire
        return matiereDTO;
    }

    // Méthode de conversion du DTO vers l'entité
    public MatiereEntite toEntity() {
        MatiereEntite matiere = new MatiereEntite();
        matiere.setIdMatiere(this.idMatiere);
        matiere.setNom(this.nom);
        matiere.setVolumeHoraire(this.volumeHoraire);
        matiere.setModule(this.module.toEntity());
        // Assurez-vous de gérer la conversion des autres attributs si nécessaire
        return matiere;
    }
}
